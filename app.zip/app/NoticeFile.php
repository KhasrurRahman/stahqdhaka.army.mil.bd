<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NoticeFile extends Model
{
    protected $guarded = [];


}
