<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slogan extends Model
{
    protected $guarded = [];
    protected $dates = ['created_at'];
}
